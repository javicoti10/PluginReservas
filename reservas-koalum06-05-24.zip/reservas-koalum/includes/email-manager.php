<?php
// Función para enviar el correo electrónico de confirmación al cliente
function rk_send_confirmation_email($customer_email, $reservation_id, $status, $reservation_details) {
    global $rk_reservation_details;
    $rk_reservation_details = $reservation_details;

    // Asegúrate de que la opción de asunto existe y usa un valor predeterminado en caso contrario
    $subject = get_option('koalum_settings')['email_subject'] ?? 'Confirmación de su reserva';
    $headers = array('Content-Type: text/html; charset=UTF-8');

    // Obtener la plantilla de correo guardada y reemplazar los shortcodes por los datos reales
    $template = get_option('rk_email_template', 'Su reserva está confirmada para [rk_date] a las [rk_time] para [rk_people] personas.');
    $message = do_shortcode($template);

    // Enviar el correo electrónico usando la función wp_mail de WordPress
    wp_mail($customer_email, $subject, $message, $headers);
}

// Función para enviar un correo electrónico al administrador del sitio con enlaces para confirmar o cancelar la reserva
function rk_send_admin_notification_email($customer_email, $reservation_id) {
    $admin_email = get_option('admin_email', get_bloginfo('admin_email')); // Utiliza el email del blog si admin_email no está definido
    $confirm_link = admin_url('admin-post.php?action=confirm_reservation&reservation_id=' . $reservation_id);
    $cancel_link = admin_url('admin-post.php?action=cancel_reservation&reservation_id=' . $reservation_id);
    $message = "Nueva reserva de {$customer_email}. <a href='{$confirm_link}'>Confirmar</a> | <a href='{$cancel_link}'>Cancelar</a>";

    // Enviar el correo electrónico al administrador
    wp_mail($admin_email, 'Nueva reserva recibida', $message);
}

