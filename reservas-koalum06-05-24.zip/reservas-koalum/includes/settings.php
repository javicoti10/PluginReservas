<?php
if (!defined('ABSPATH')) exit; // Protección contra acceso directo no autorizado

function koalum_add_admin_menu() {
    // Añade una página al menú de administración con el nombre personalizado del plugin
    add_menu_page('Configuración de Plugin Reservas Javi', 'Plugin Reservas Javi', 'manage_options', 'koalum', 'koalum_options_page');
}
add_action('admin_menu', 'koalum_add_admin_menu');

function koalum_register_settings() {
    // Registra las configuraciones del plugin
    register_setting('koalum_settings_group', 'koalum_settings', 'koalum_settings_validate');

    // Añade una sección de configuración para personalización de emails
    add_settings_section('koalum_email_settings', 'Personalización de Emails', 'koalum_settings_section_callback', 'koalum');

    // Asunto y contenido del Email de Confirmación
    add_settings_field('koalum_email_subject', 'Asunto del Email de Confirmación', 'koalum_email_subject_field_callback', 'koalum', 'koalum_email_settings', array('field' => 'email_subject'));
    add_settings_field('koalum_email_confirmed', 'Email de Reserva Confirmada', 'koalum_email_field_callback', 'koalum', 'koalum_email_settings', array('field' => 'email_confirmed'));

    // Asunto y contenido del Email de Reserva Pendiente
    add_settings_field('koalum_email_subject_pending', 'Asunto del Email de Reserva Pendiente', 'koalum_email_subject_field_callback', 'koalum', 'koalum_email_settings', array('field' => 'email_subject_pending'));
    add_settings_field('koalum_email_pending', 'Email de Reserva Pendiente', 'koalum_email_field_callback', 'koalum', 'koalum_email_settings', array('field' => 'email_pending'));

    // Asunto y contenido del Email de Reserva Rechazada
    add_settings_field('koalum_email_subject_rejected', 'Asunto del Email de Reserva Rechazada', 'koalum_email_subject_field_callback', 'koalum', 'koalum_email_settings', array('field' => 'email_subject_rejected'));
    add_settings_field('koalum_email_cancelled', 'Email de Reserva Cancelada', 'koalum_email_field_callback', 'koalum', 'koalum_email_settings', array('field' => 'email_cancelled'));

    // Función que genera campos de texto para asuntos de emails
    function koalum_email_subject_field_callback($args) {
        $options = get_option('koalum_settings');
        $email_subject = isset($options[$args['field']]) ? $options[$args['field']] : 'Asunto predeterminado';
        echo '<input type="text" id="' . $args['field'] . '" name="koalum_settings[' . $args['field'] . ']" value="' . esc_attr($email_subject) . '" />';
    }

    // Función que genera campos de texto para contenido de emails
    function koalum_email_field_callback($args) {
        $options = get_option('koalum_settings');
        $field = $args['field'];
        echo "<textarea name='koalum_settings[$field]' rows='5' cols='50'>" . esc_textarea($options[$field]) . "</textarea>";
    }

    add_settings_section('koalum_schedule_settings', 'Configuración de Horarios', 'koalum_settings_section_callback', 'koalum');
    $days = ['lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado', 'domingo'];
    foreach ($days as $day) {
        add_settings_field("{$day}_schedule", ucfirst($day), 'koalum_day_schedule_field_callback', 'koalum', 'koalum_schedule_settings', array('day' => $day));
    }
}
add_action('admin_init', 'koalum_register_settings');

function koalum_settings_section_callback() {
    echo '<p>Configura los detalles de los emails y los horarios de reserva aquí.</p>';
}

function koalum_day_schedule_field_callback($args) {
    $options = get_option('koalum_settings');
    $day = $args['day'];
    echo "Almuerzo inicio: <input type='time' name='koalum_settings[{$day}_lunch_start]' value='" . esc_attr($options["{$day}_lunch_start"]) . "'>";
    echo " Almuerzo fin: <input type='time' name='koalum_settings[{$day}_lunch_end]' value='" . esc_attr($options["{$day}_lunch_end"]) . "'>";
    echo " Cena inicio: <input type='time' name='koalum_settings[{$day}_dinner_start]' value='" . esc_attr($options["{$day}_dinner_start"]) . "'>";
    echo " Cena fin: <input type='time' name='koalum_settings[{$day}_dinner_end]' value='" . esc_attr($options["{$day}_dinner_end"]) . "'>";
}

function koalum_options_page() {
    ?>
    <div class="wrap">
        <h2>Configuración de Plugin Reservas Javi</h2>
        <form action="options.php" method="post">
            <?php
            settings_fields('koalum_settings_group');
            do_settings_sections('koalum');
            submit_button('Guardar Cambios');
            ?>
        </form>
    </div>
    <?php
}

function koalum_settings_validate($input) {
    // Función para validar las entradas de configuración
    return $input;
}

