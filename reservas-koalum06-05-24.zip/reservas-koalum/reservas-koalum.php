<?php
/*
Plugin Name: Plugin Reservas Javi Cotilla
Plugin URI: https://koalum.com/pruebaplugin
Description: Motor de reservas para restaurantes.
Version: 1.0
Author: Javier Cotilla Segovia
Author URI: https://koalum.com
Text Domain: reservas-koalum
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

// Incluir estilos y scripts
function rk_enqueue_scripts() {
    wp_enqueue_style('rk-reservas-style', plugin_dir_url(__FILE__) . 'assets/css/style.css');
    wp_enqueue_script('rk-reservas-script', plugin_dir_url(__FILE__) . 'assets/js/main.js', array('jquery'), false, true);
}
add_action('wp_enqueue_scripts', 'rk_enqueue_scripts');

// Agregar menús al panel de administración
function rk_add_admin_menu() {
    add_menu_page('Plugin Reservas Javi', 'Plugin Reservas Javi', 'manage_options', 'koalum', 'rk_main_menu_page');
    add_submenu_page('koalum', 'Personalización de Emails', 'Emails', 'manage_options', 'rk-emails', 'rk_emails_submenu_page');
    add_submenu_page('koalum', 'Configuración de Horarios', 'Horarios', 'manage_options', 'rk-settings', 'rk_settings_submenu_page');
}
add_action('admin_menu', 'rk_add_admin_menu');

function rk_main_menu_page() {
    echo '<h1>Bienvenido a mi Plugin de Reservas</h1>';
}

function rk_emails_submenu_page() {
    // Asegúrate de que la ruta es correcta y el archivo existe
    include_once plugin_dir_path(__FILE__) . 'includes/email-manager.php';
}

function rk_settings_submenu_page() {
    // Asegúrate de que la ruta es correcta y el archivo existe
    include_once plugin_dir_path(__FILE__) . 'includes/settings.php';
}

// Cargar archivos necesarios
include_once plugin_dir_path(__FILE__) . 'includes/form-handler.php';
include_once plugin_dir_path(__FILE__) . 'includes/installer.php';
include_once plugin_dir_path(__FILE__) . 'includes/utilities.php';
include_once plugin_dir_path(__FILE__) . 'includes/email-manager.php';
include_once plugin_dir_path(__FILE__) . 'includes/settings.php';

// Shortcode para insertar el formulario de reservas
function rk_reservas_form_shortcode() {
    ob_start();
    include(plugin_dir_path(__FILE__) . 'templates/form-template.php');
    return ob_get_clean();
}
add_shortcode('formulario_reservas', 'rk_reservas_form_shortcode');

// Hook para crear la tabla en la base de datos al activar el plugin
function rk_activate_plugin() {
    rk_install();
}
register_activation_hook(__FILE__, 'rk_activate_plugin');

// Archivo principal del plugin, carga componentes y define el shortcode.
